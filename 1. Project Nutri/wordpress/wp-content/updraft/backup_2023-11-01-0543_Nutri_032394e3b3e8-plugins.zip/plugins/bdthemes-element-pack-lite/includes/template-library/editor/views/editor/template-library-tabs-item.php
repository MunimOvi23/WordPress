<?php
/**
 * Template Library Header Template
 */
if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<label>
	<input type="radio" value="{{ term_slug }}" name="bdt-elementpack-library-tab">
	<span>{{ title }}</span>
</label>