<?php
/**
 * templates loader view
 */
if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<div class="elementor-library-error">
	<div class="elementor-library-error-message" style="color:red;"><?php
		_e( 'Template couldn\'t be loaded. Please activate you license key before.', 'bdthemes-element-pack' );
	?></div>
	<div class="elementor-library-error-link"><?php

	?></div>
</div>