<?php
/**
 * Templates list view
 */
if (!defined('ABSPATH')) exit; // Exit if accessed directly
?>
<div id="bdt-elementpack-template-library-templates-container"></div>